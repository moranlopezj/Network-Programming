import java.util.ArrayList;

//never do "new CardCollection()"

abstract public class CardCollection {
	
	//data
	protected ArrayList<Card> cards;
	
	//constructor
	protected CardCollection(int size){
		cards = new ArrayList<Card>(size);
	}
	
	public void addCard(Card c) {
		cards.add(c);
	}
	
	public void removeCard(Card c) {
		cards.remove(c);
	}
	
	
}
