
public class Hand extends CardCollection {
	
	public Hand() {
		super(5);
	}
	
	public int getValue() {
		int sum = 0;
		for (int i = 0; i < cards.size(); i++) {
			Card c = cards.get(i);
			if (!c.isFlipped()) { //card is face up
				sum += c.getValue();
			}
			//sum += cards.get(i).getValue();
		}
		return sum;
	}
	
	public String toString() {
		String s = "";
		for(int i = 0; i < cards.size(); i++) {
			s += String.format("%s ", cards.get(i));
		}
		s += String.format("Showing (%d)%n", getValue());
		return s;
	}
	
}
