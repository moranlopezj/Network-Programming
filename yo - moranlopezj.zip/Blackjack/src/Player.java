import java.util.Scanner;

public class Player extends GenericPlayer{

	public Player(String name) {
		super(name);
	}

	@Override
	public boolean isHitting(Scanner s) {
		do {
			System.out.printf("%s: Do you want to hit (y/n)?", name);
			String ans = s.next();
			if(ans.length()==0) {
				continue;
			} else if (ans.charAt(0)== 'y'){
				return true;
			} else if(ans.charAt(0)== 'n'){
				return false;
			} else {
				System.out.printf("Please enter y or n.%n");
			}
			
		} while (true);
	}

	public void win() {
		System.out.printf("%s: Wins!%n", name);
	}
	
	public void lose() {
		System.out.printf("%s: Lost!%n", name);
	}
	
	public void push() {
		System.out.printf("%s: Pushed!%n", name);
	}
	
}
